console.log("KnightRealm Website Loaded");

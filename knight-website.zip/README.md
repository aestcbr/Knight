# KnightRealm Website

Medieval knight-themed website project.

## Features
- Knight / medieval theme
- Simple layout
- Ready for GitHub upload

## How to run
Open index.html in your browser.
